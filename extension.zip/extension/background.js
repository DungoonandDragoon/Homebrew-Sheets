// background.js — Manifest V3 service worker

// In MV3, message listeners that call sendResponse asynchronously
// must return true synchronously to keep the port open.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'CONTENT_READY') return false;

  if (message.type === 'HOMEBREW_SHEET_ROLL') {
    forwardRollToDDB(message.payload)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true; // keep port open for async response
  }

  return false;
});

async function forwardRollToDDB(payload) {
  const tabs = await chrome.tabs.query({ url: 'https://www.dndbeyond.com/*' });

  for (const tab of tabs) {
    // First try sending directly — works if content script already loaded
    try {
      await chrome.tabs.sendMessage(tab.id, { type: 'HOMEBREW_ROLL', payload });
      continue;
    } catch (_) {}

    // Content script not loaded yet — inject it then send
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js'],
      });
      // Small delay to let the script initialize
      await new Promise(r => setTimeout(r, 150));
      await chrome.tabs.sendMessage(tab.id, { type: 'HOMEBREW_ROLL', payload });
    } catch (e) {
      console.warn('[HBS] Could not deliver roll to tab', tab.id, e.message);
    }
  }
}
