// content.js — runs on every DnDBeyond page
// Since DnDBeyond's game log cannot be written to externally,
// this script displays an on-page overlay showing roll results
// and optionally posts to a Discord webhook.

(function () {
  'use strict';

  // ── Listen for messages from the background relay ─────────────────────────
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type !== 'HOMEBREW_ROLL') return;
    handleRoll(message.payload);
    sendResponse({ ok: true });
  });

  function handleRoll(payload) {
    const { label, total, breakdown, characterName } = payload;
    showRollOverlay(label, total, breakdown, characterName);
    tryDiscordWebhook(payload);
  }

  // ── Roll overlay ───────────────────────────────────────────────────────────
  // A persistent roll feed in the corner of the DDB page that shows recent
  // rolls from the Homebrew Sheet, styled to match DDB's dark theme.

  function getOrCreateFeed() {
    let feed = document.getElementById('hbs-roll-feed');
    if (feed) return feed;

    feed = document.createElement('div');
    feed.id = 'hbs-roll-feed';
    feed.style.cssText = `
      position: fixed;
      bottom: 80px;
      right: 20px;
      width: 220px;
      z-index: 99999;
      display: flex;
      flex-direction: column;
      gap: 6px;
      pointer-events: none;
    `;
    document.body.appendChild(feed);
    return feed;
  }

  function showRollOverlay(label, total, breakdown, characterName) {
    const feed = getOrCreateFeed();

    const card = document.createElement('div');
    card.style.cssText = `
      background: rgba(13,13,15,0.97);
      border: 1px solid #c9a84c;
      border-radius: 8px;
      padding: 10px 14px;
      font-family: -apple-system, sans-serif;
      box-shadow: 0 4px 20px rgba(0,0,0,0.7);
      animation: hbs-in 0.2s ease;
      pointer-events: all;
    `;

    // Inject keyframes once
    if (!document.getElementById('hbs-styles')) {
      const style = document.createElement('style');
      style.id = 'hbs-styles';
      style.textContent = `
        @keyframes hbs-in { from { opacity:0; transform:translateY(6px); } to { opacity:1; transform:translateY(0); } }
        @keyframes hbs-out { from { opacity:1; } to { opacity:0; } }
      `;
      document.head.appendChild(style);
    }

    card.innerHTML = `
      <div style="font-size:10px;letter-spacing:0.1em;text-transform:uppercase;color:#8a8070;margin-bottom:2px;">
        ${escapeHtml(characterName || 'Homebrew Sheet')}
      </div>
      <div style="font-size:11px;color:#c9a84c;margin-bottom:4px;">
        ${escapeHtml(label)}
      </div>
      <div style="font-size:30px;font-weight:700;color:#e8e0d0;line-height:1;">
        ${total}
      </div>
      <div style="font-size:11px;color:#5a5548;margin-top:3px;">
        ${escapeHtml(breakdown)}
      </div>
    `;

    feed.appendChild(card);

    // Auto-remove after 8 seconds
    setTimeout(() => {
      card.style.animation = 'hbs-out 0.3s ease forwards';
      setTimeout(() => card.remove(), 300);
    }, 8000);
  }

  // ── Discord webhook (optional) ─────────────────────────────────────────────
  // If the user has set a Discord webhook URL in the extension's storage,
  // roll results will also be posted there.

  async function tryDiscordWebhook(payload) {
    try {
      const { discordWebhook } = await chrome.storage.local.get('discordWebhook');
      if (!discordWebhook) return;

      const { label, total, breakdown, characterName } = payload;
      const content = `🎲 **${characterName || 'Homebrew Sheet'}** — **${label}**: **${total}** *(${breakdown})*`;

      await fetch(discordWebhook, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content }),
      });
    } catch (_) {
      // Webhook not configured or failed — silently ignore
    }
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  // Signal alive
  chrome.runtime.sendMessage({ type: 'CONTENT_READY', url: window.location.href }).catch(() => {});

})();
