// popup.js
const SHEET_URL = 'https://dungoonanddragoon.github.io/Homebrew-Sheets';

async function init() {
  // Check DnDBeyond tabs
  const ddbTabs = await chrome.tabs.query({ url: 'https://www.dndbeyond.com/*' });
  const ddbDot = document.getElementById('ddb-dot');
  const ddbStatus = document.getElementById('ddb-status');
  if (ddbTabs.length > 0) {
    ddbDot.classList.add('green');
    ddbStatus.textContent = `DnDBeyond open (${ddbTabs.length} tab${ddbTabs.length > 1 ? 's' : ''})`;
  } else {
    ddbDot.classList.add('amber');
    ddbStatus.textContent = 'No DnDBeyond tab open';
  }

  // Check sheet tabs
  const sheetTabs = await chrome.tabs.query({ url: `${SHEET_URL}*` });
  const sheetDot = document.getElementById('sheet-dot');
  const sheetStatus = document.getElementById('sheet-status');
  if (sheetTabs.length > 0) {
    sheetDot.classList.add('green');
    sheetStatus.textContent = 'Homebrew Sheet is open';
  } else {
    sheetDot.classList.add('amber');
    sheetStatus.textContent = 'Sheet not open';
  }

  // Load last roll
  const { lastRoll } = await chrome.storage.local.get('lastRoll');
  if (lastRoll) {
    document.getElementById('last-roll-label').textContent = lastRoll.label;
    document.getElementById('last-roll-total').textContent = lastRoll.total;
    document.getElementById('last-roll-breakdown').textContent = lastRoll.breakdown;
  }

  // Load saved webhook
  const { discordWebhook } = await chrome.storage.local.get('discordWebhook');
  if (discordWebhook) {
    document.getElementById('webhook-input').value = discordWebhook;
  }

  // Save webhook
  document.getElementById('save-webhook').addEventListener('click', async () => {
    const val = document.getElementById('webhook-input').value.trim();
    await chrome.storage.local.set({ discordWebhook: val });
    const msg = document.getElementById('saved-msg');
    msg.style.display = 'block';
    setTimeout(() => { msg.style.display = 'none'; }, 2000);
  });

  // Open sheet button
  document.getElementById('open-sheet').addEventListener('click', () => {
    if (sheetTabs.length > 0) {
      chrome.tabs.update(sheetTabs[0].id, { active: true });
    } else {
      chrome.tabs.create({ url: SHEET_URL });
    }
    window.close();
  });
}

init();
